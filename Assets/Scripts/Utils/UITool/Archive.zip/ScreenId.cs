namespace Utils.UITool
{
    public enum ScreenId
    {
        MENU,
        LEVEL_COMPLETED,
        SELECT_STORY,
        STORY_LEVEL,
        SURVIVAL_LEVEL,
        MESSAGE,
        CONNECTION_LOST,
        SELECT_CASUAL,
        CASUAL_LEVEL
    }
}