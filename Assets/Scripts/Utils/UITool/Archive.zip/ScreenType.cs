namespace Utils.UITool
{
    public enum ScreenType
    {
        SCREEN,
        POPUP
    }
}