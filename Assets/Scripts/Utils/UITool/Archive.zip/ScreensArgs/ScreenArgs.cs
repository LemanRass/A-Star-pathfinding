namespace Utils.UITool.ScreensArgs
{
    public class ScreenArgs
    {
        public bool isInstant;
    }
}